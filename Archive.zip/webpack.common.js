const path = require("path");
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
    entry: {
        index: "./src/js/index.js",
      


    },
    plugins: [
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: 'src/pages/index.html',
            chunks: ['index']
        }),
        new HtmlWebpackPlugin({
            filename: 'about.html',
            template: 'src/pages/about.html',
            chunks: ['index']
        }),
  
    ],

    module: {
        rules: [

            {
                test: /\.html/,
                use: [{
                    loader: "html-loader",

                }]
            },
            {
                test: /\.(png|jpg|gif|svg)$/,
                use: {
                    loader: "file-loader",
                    options: {
                        name: "[name].[hash].[ext]",
                        outputPath: "images",
                        esModule: false,
                    }
                }
            }
        ]
    }
}