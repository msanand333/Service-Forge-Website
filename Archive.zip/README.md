# MostWantedRecipes(PWA)
A small demo on how to make a progressive web application.
